package com.example.storyapp.data.session

class LoginModel {
}