package com.example.storyapp.data.api.response

data class RegisterResponse(
    val error: Boolean,
    val message: String
)